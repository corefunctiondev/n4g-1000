class ContentLoader {
    constructor() {
        this.config = null;
        this.loadContent();
    }
    
    async loadContent() {
        try {
            // First try to load from localStorage (admin updates)
            const localConfig = localStorage.getItem('n4g-site-config');
            if (localConfig) {
                this.config = JSON.parse(localConfig);
                this.updateSiteContent();
                return;
            }
            
            // Fallback to original config file
            const response = await fetch('/content/site-config.json');
            this.config = await response.json();
            this.updateSiteContent();
        } catch (error) {
            console.error('Failed to load content configuration:', error);
            // Fallback to default content if config fails to load
        }
    }
    
    updateSiteContent() {
        if (!this.config) return;
        
        // Update site info
        this.updateSiteInfo();
        
        // Update member profiles
        this.updateMemberProfiles();
        
        // Update story
        this.updateStory();
        
        // Update DJ sets
        this.updateDJSets();
        
        // Update podcasts
        this.updatePodcasts();
        
        // Update bookings
        this.updateBookings();
        
        // Update releases
        this.updateReleases();
        
        // Update mixes
        this.updateMixes();
        
        // Update contact info
        this.updateContactInfo();
        
        // Update social links
        this.updateSocialLinks();
        
        // Update footer
        this.updateFooter();
    }
    
    updateSiteInfo() {
        const { siteInfo } = this.config;
        
        // Update title
        document.title = siteInfo.title;
        
        // Update OS version
        const osVersion = document.querySelector('.os-version');
        if (osVersion) osVersion.textContent = siteInfo.title;
        
        // Update copyright
        const copyright = document.querySelector('.copyright');
        if (copyright) copyright.textContent = siteInfo.copyright;
        
        // Update logo
        const logo = document.querySelector('.n4g-logo');
        if (logo) logo.textContent = siteInfo.logo;
        
        // Update menu title
        const menuTitle = document.querySelector('.menu-title');
        if (menuTitle) menuTitle.textContent = siteInfo.logo.split(' ').map(word => word.substring(0, 3).toUpperCase()).join('') + ' OS';
        
        // Update terminal titles
        const terminalTitles = document.querySelectorAll('.window-title');
        terminalTitles.forEach(title => {
            const prefix = siteInfo.logo.toLowerCase().replace(/\s+/g, '').substring(0, 3);
            title.textContent = `${prefix}@system:~$`;
        });
        
        // Update prompts
        const prompts = document.querySelectorAll('.prompt');
        prompts.forEach(prompt => {
            const prefix = siteInfo.logo.toLowerCase().replace(/\s+/g, '').substring(0, 3);
            prompt.textContent = `${prefix}@system:~$`;
        });
        
        // Update description in boot sequence
        const bootLines = document.querySelectorAll('.boot-line');
        if (bootLines.length > 7) {
            bootLines[7].textContent = `Welcome to ${siteInfo.title}`;
            bootLines[8].textContent = siteInfo.description;
        }
    }
    
    updateMemberProfiles() {
        const { members } = this.config;
        const memberCards = document.querySelectorAll('.member-card');
        
        members.forEach((member, index) => {
            if (memberCards[index]) {
                const card = memberCards[index];
                
                // Update member header
                const memberHeader = card.querySelector('.member-header h3');
                if (memberHeader) memberHeader.textContent = `MEMBER_${String(index + 1).padStart(2, '0')}/`;
                
                // Update status indicator
                const statusIndicator = card.querySelector('.status-indicator');
                if (statusIndicator) {
                    statusIndicator.className = `status-indicator ${member.status}`;
                }
                
                // Update member info
                const infoLines = card.querySelectorAll('.info-line');
                if (infoLines.length >= 5) {
                    infoLines[0].textContent = `Name: ${member.name}`;
                    infoLines[1].textContent = `Origin: ${member.origin}`;
                    infoLines[2].textContent = `Specialty: ${member.specialty}`;
                    infoLines[3].textContent = `Equipment: ${member.equipment}`;
                    infoLines[4].textContent = `Years Active: ${member.yearsActive}`;
                }
            }
        });
    }
    
    updateStory() {
        const { story } = this.config;
        
        const storyTitle = document.querySelector('.subsection-title');
        if (storyTitle) storyTitle.textContent = `├─${story.title} ⊟`;
        
        const storyContent = document.querySelector('.story-content p');
        if (storyContent) storyContent.textContent = story.content;
    }
    
    updateDJSets() {
        const { djSets } = this.config;
        const setsGrid = document.querySelector('.sets-grid');
        
        if (setsGrid) {
            setsGrid.innerHTML = '';
            
            djSets.forEach(set => {
                const setItem = document.createElement('div');
                setItem.className = 'set-item';
                setItem.innerHTML = `
                    <div class="set-thumbnail">
                        <img src="${set.thumbnail}" alt="${set.title}">
                        <div class="play-overlay">▶</div>
                        <div class="duration">${set.duration}</div>
                    </div>
                    <div class="set-info">
                        <div class="set-title">${set.title}</div>
                        <div class="set-details">${set.details}</div>
                    </div>
                `;
                
                // Add click handler if URL is provided
                if (set.url && set.url !== '#') {
                    setItem.addEventListener('click', () => {
                        window.open(set.url, '_blank');
                    });
                }
                
                setsGrid.appendChild(setItem);
            });
        }
    }
    
    updatePodcasts() {
        const { podcasts } = this.config;
        const podcastList = document.querySelector('.podcast-list');
        
        if (podcastList) {
            podcastList.innerHTML = '';
            
            podcasts.forEach(podcast => {
                const podcastItem = document.createElement('div');
                podcastItem.className = 'podcast-item';
                podcastItem.innerHTML = `
                    <span class="episode-number">${podcast.episode}</span>
                    <span class="episode-title">${podcast.title}</span>
                    <span class="episode-date">${podcast.date}</span>
                `;
                podcastList.appendChild(podcastItem);
            });
        }
    }
    
    updateBookings() {
        const { bookings } = this.config;
        const bookingsTable = document.querySelector('.bookings-table');
        
        if (bookingsTable) {
            // Keep the header row
            const headerRow = bookingsTable.querySelector('.header-row');
            bookingsTable.innerHTML = '';
            bookingsTable.appendChild(headerRow);
            
            bookings.forEach(booking => {
                const bookingRow = document.createElement('div');
                bookingRow.className = 'booking-row';
                bookingRow.innerHTML = `
                    <div class="booking-date">${booking.date}</div>
                    <div class="booking-venue">${booking.venue}</div>
                    <div class="booking-location">${booking.location}</div>
                    <div class="booking-type">${booking.type}</div>
                    <div class="booking-status ${booking.status}">${booking.status.toUpperCase()}</div>
                `;
                bookingsTable.appendChild(bookingRow);
            });
        }
    }
    
    updateReleases() {
        const { releases } = this.config;
        const releasesGrid = document.querySelector('.releases-grid');
        
        if (releasesGrid) {
            releasesGrid.innerHTML = '';
            
            releases.forEach(release => {
                const releaseItem = document.createElement('div');
                releaseItem.className = 'release-item';
                releaseItem.innerHTML = `
                    <div class="release-cover">
                        <img src="${release.cover}" alt="${release.title}">
                    </div>
                    <div class="release-info">
                        <div class="release-title">${release.title}</div>
                        <div class="release-label">${release.label}</div>
                        <div class="release-year">${release.year}</div>
                    </div>
                `;
                
                // Add click handler if URL is provided
                if (release.url && release.url !== '#') {
                    releaseItem.addEventListener('click', () => {
                        window.open(release.url, '_blank');
                    });
                }
                
                releasesGrid.appendChild(releaseItem);
            });
        }
    }
    
    updateMixes() {
        const { mixes } = this.config;
        const mixList = document.querySelector('.mix-list');
        
        if (mixList) {
            mixList.innerHTML = '';
            
            mixes.forEach(mix => {
                const mixItem = document.createElement('div');
                mixItem.className = 'mix-item';
                mixItem.innerHTML = `
                    <span class="mix-icon">${mix.icon}</span>
                    <div class="mix-details">
                        <span class="mix-name">${mix.name}</span>
                        <span class="mix-description">${mix.description}</span>
                    </div>
                `;
                mixList.appendChild(mixItem);
            });
        }
    }
    
    updateContactInfo() {
        const { contact } = this.config;
        const contactSections = document.querySelectorAll('.contact-section');
        
        // Update bookings section
        if (contactSections[0]) {
            const bookingsInfo = contactSections[0].querySelector('.contact-info');
            if (bookingsInfo) {
                bookingsInfo.innerHTML = `
                    <p>${contact.bookings.email}</p>
                    <p>${contact.bookings.phone}</p>
                `;
            }
        }
        
        // Update management section
        if (contactSections[1]) {
            const managementInfo = contactSections[1].querySelector('.contact-info');
            if (managementInfo) {
                managementInfo.innerHTML = `
                    <p>${contact.management.email}</p>
                    <p>${contact.management.company}</p>
                `;
            }
        }
        
        // Update press section
        if (contactSections[2]) {
            const pressInfo = contactSections[2].querySelector('.contact-info');
            if (pressInfo) {
                pressInfo.innerHTML = `
                    <p>${contact.press.email}</p>
                    <p>${contact.press.note}</p>
                `;
            }
        }
        
        // Update booking info section
        const bookingDetails = document.querySelector('.booking-details');
        if (bookingDetails) {
            bookingDetails.innerHTML = `
                <p>For bookings and inquiries, contact our management:</p>
                <p>Email: ${contact.bookings.email}</p>
                <p>Phone: ${contact.bookings.phone}</p>
                <p>Based in NYC - Available worldwide</p>
            `;
        }
    }
    
    updateSocialLinks() {
        const { socialLinks } = this.config;
        
        // Update menu social links
        const socialLinksContainer = document.querySelector('.social-links');
        if (socialLinksContainer) {
            socialLinksContainer.innerHTML = '';
            
            socialLinks.forEach(social => {
                const listItem = document.createElement('li');
                listItem.innerHTML = `<a href="${social.url}" class="social-link" target="_blank">${social.name}</a>`;
                socialLinksContainer.appendChild(listItem);
            });
        }
        
        // Update footer social links
        const footerSocial = document.querySelector('.footer-social');
        if (footerSocial) {
            footerSocial.innerHTML = '';
            
            socialLinks.forEach(social => {
                const socialLink = document.createElement('a');
                socialLink.href = social.url;
                socialLink.target = '_blank';
                socialLink.textContent = social.name;
                footerSocial.appendChild(socialLink);
            });
        }
    }
    
    updateFooter() {
        const { siteInfo } = this.config;
        
        // Update footer brand
        const footerLogo = document.querySelector('.footer-logo');
        if (footerLogo) footerLogo.textContent = siteInfo.logo;
        
        const footerTagline = document.querySelector('.footer-tagline');
        if (footerTagline) footerTagline.textContent = siteInfo.description;
        
        // Update footer copyright
        const copyrightText = document.querySelector('.copyright-text');
        if (copyrightText) copyrightText.textContent = siteInfo.copyright;
        
        // Update tech info
        const techInfo = document.querySelector('.tech-info');
        if (techInfo) techInfo.textContent = `Powered by ${siteInfo.title}`;
    }
}

// Initialize content loader when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.contentLoader = new ContentLoader();
});