class AdminSystem {
    constructor() {
        this.isAuthenticated = false;
        this.currentConfig = null;
        this.currentTab = 'site-info';
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.checkAuthStatus();
    }
    
    checkAuthStatus() {
        const session = localStorage.getItem('n4g-admin-session');
        if (session === 'authenticated') {
            this.isAuthenticated = true;
        }
    }
    
    setupEventListeners() {
        // Admin login form
        const loginForm = document.getElementById('adminLoginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
        
        // Admin logout
        const logoutBtn = document.getElementById('adminLogout');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }
        
        // Save changes
        const saveBtn = document.getElementById('saveChanges');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveChanges());
        }
        
        // Admin tabs
        const adminTabs = document.querySelectorAll('.admin-tab');
        adminTabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.target.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });
    }
    
    async handleLogin(e) {
        e.preventDefault();
        
        const username = document.getElementById('adminUsername').value;
        const password = document.getElementById('adminPassword').value;
        const submitBtn = document.getElementById('adminSubmit');
        const errorDiv = document.getElementById('adminError');
        
        submitBtn.textContent = 'AUTHENTICATING...';
        submitBtn.disabled = true;
        
        // Simulate authentication delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        if (username === 'n4gadmin' && password === 'groove2024!') {
            localStorage.setItem('n4g-admin-session', 'authenticated');
            this.isAuthenticated = true;
            errorDiv.style.display = 'none';
            
            // Load current config
            await this.loadConfig();
            
            // Switch to admin panel
            if (window.n4gOS) {
                window.n4gOS.navigateToSection('admin-panel');
            }
            
            // Load the first tab
            this.loadTabContent('site-info');
            
        } else {
            errorDiv.style.display = 'block';
            this.isAuthenticated = false;
        }
        
        submitBtn.textContent = 'ACCESS SYSTEM';
        submitBtn.disabled = false;
    }
    
    handleLogout() {
        localStorage.removeItem('n4g-admin-session');
        this.isAuthenticated = false;
        this.currentConfig = null;
        
        // Clear form
        document.getElementById('adminUsername').value = '';
        document.getElementById('adminPassword').value = '';
        
        // Navigate back to home
        if (window.n4gOS) {
            window.n4gOS.navigateToSection('home');
        }
    }
    
    async loadConfig() {
        try {
            // Try to load from localStorage first (saved changes)
            const localConfig = localStorage.getItem('n4g-site-config');
            if (localConfig) {
                this.currentConfig = JSON.parse(localConfig);
                return;
            }
            
            // Fallback to original config
            const response = await fetch('/content/site-config.json');
            this.currentConfig = await response.json();
        } catch (error) {
            console.error('Failed to load config:', error);
        }
    }
    
    switchTab(tabName) {
        // Update active tab
        document.querySelectorAll('.admin-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        
        this.currentTab = tabName;
        this.loadTabContent(tabName);
    }
    
    loadTabContent(tabName) {
        const contentDiv = document.getElementById('adminContent');
        if (!contentDiv || !this.currentConfig) return;
        
        switch (tabName) {
            case 'site-info':
                contentDiv.innerHTML = this.renderSiteInfoTab();
                break;
            case 'members':
                contentDiv.innerHTML = this.renderMembersTab();
                break;
            case 'story':
                contentDiv.innerHTML = this.renderStoryTab();
                break;
            case 'sets':
                contentDiv.innerHTML = this.renderSetsTab();
                break;
            case 'bookings':
                contentDiv.innerHTML = this.renderBookingsTab();
                break;
            case 'releases':
                contentDiv.innerHTML = this.renderReleasesTab();
                break;
            case 'contact':
                contentDiv.innerHTML = this.renderContactTab();
                break;
            case 'social':
                contentDiv.innerHTML = this.renderSocialTab();
                break;
        }
        
        this.setupTabEventListeners();
    }
    
    renderSiteInfoTab() {
        const { siteInfo } = this.currentConfig;
        return `
            <div class="admin-form-section">
                <h3>Site Information</h3>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Site Title:</label>
                        <input type="text" id="siteTitle" value="${siteInfo.title}" />
                    </div>
                    <div class="form-group">
                        <label>Logo Text:</label>
                        <input type="text" id="siteLogo" value="${siteInfo.logo}" />
                    </div>
                    <div class="form-group">
                        <label>Copyright:</label>
                        <input type="text" id="siteCopyright" value="${siteInfo.copyright}" />
                    </div>
                    <div class="form-group full-width">
                        <label>Description:</label>
                        <textarea id="siteDescription" rows="3">${siteInfo.description}</textarea>
                    </div>
                </div>
            </div>
        `;
    }
    
    renderMembersTab() {
        const { members } = this.currentConfig;
        let html = `
            <div class="admin-form-section">
                <div class="section-header">
                    <h3>DJ Members</h3>
                    <button class="admin-btn add-btn" onclick="adminSystem.addMember()">+ ADD MEMBER</button>
                </div>
        `;
        
        members.forEach((member, index) => {
            html += `
                <div class="member-form" data-index="${index}">
                    <div class="member-header">
                        <h4>Member ${index + 1}</h4>
                        <button class="admin-btn delete-btn" onclick="adminSystem.removeMember(${index})">🗑️</button>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Name:</label>
                            <input type="text" data-field="name" value="${member.name}" />
                        </div>
                        <div class="form-group">
                            <label>Origin:</label>
                            <input type="text" data-field="origin" value="${member.origin}" />
                        </div>
                        <div class="form-group">
                            <label>Specialty:</label>
                            <input type="text" data-field="specialty" value="${member.specialty}" />
                        </div>
                        <div class="form-group">
                            <label>Equipment:</label>
                            <input type="text" data-field="equipment" value="${member.equipment}" />
                        </div>
                        <div class="form-group">
                            <label>Years Active:</label>
                            <input type="number" data-field="yearsActive" value="${member.yearsActive}" />
                        </div>
                        <div class="form-group">
                            <label>Status:</label>
                            <select data-field="status">
                                <option value="online" ${member.status === 'online' ? 'selected' : ''}>Online</option>
                                <option value="offline" ${member.status === 'offline' ? 'selected' : ''}>Offline</option>
                                <option value="busy" ${member.status === 'busy' ? 'selected' : ''}>Busy</option>
                            </select>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    renderStoryTab() {
        const { story } = this.currentConfig;
        return `
            <div class="admin-form-section">
                <h3>Origin Story</h3>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Story Title:</label>
                        <input type="text" id="storyTitle" value="${story.title}" />
                    </div>
                    <div class="form-group full-width">
                        <label>Story Content:</label>
                        <textarea id="storyContent" rows="8">${story.content}</textarea>
                    </div>
                </div>
            </div>
        `;
    }
    
    renderSetsTab() {
        const sets = this.currentConfig.sets || [];
        let html = `
            <div class="admin-form-section">
                <div class="section-header">
                    <h3>DJ Sets</h3>
                    <button class="admin-btn add-btn" onclick="adminSystem.addDjSet()">+ ADD SET</button>
                </div>
        `;
        
        sets.forEach((set, index) => {
            html += `
                <div class="set-form" data-index="${index}">
                    <div class="member-header">
                        <h4>Set ${index + 1}</h4>
                        <button class="admin-btn delete-btn" onclick="adminSystem.removeDjSet(${index})">🗑️</button>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Title:</label>
                            <input type="text" data-field="title" value="${set.title || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Date:</label>
                            <input type="text" data-field="date" value="${set.date || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Duration:</label>
                            <input type="text" data-field="duration" value="${set.duration || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Genre:</label>
                            <input type="text" data-field="genre" value="${set.genre || ''}" />
                        </div>
                        <div class="form-group">
                            <label>URL:</label>
                            <input type="url" data-field="url" value="${set.url || ''}" />
                        </div>
                        <div class="form-group full-width">
                            <label>Description:</label>
                            <textarea data-field="description" rows="3">${set.description || ''}</textarea>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    renderReleasesTab() {
        const releases = this.currentConfig.releases || [];
        let html = `
            <div class="admin-form-section">
                <div class="section-header">
                    <h3>Releases</h3>
                    <button class="admin-btn add-btn" onclick="adminSystem.addRelease()">+ ADD RELEASE</button>
                </div>
        `;
        
        releases.forEach((release, index) => {
            html += `
                <div class="release-form" data-index="${index}">
                    <div class="member-header">
                        <h4>Release ${index + 1}</h4>
                        <button class="admin-btn delete-btn" onclick="adminSystem.removeRelease(${index})">🗑️</button>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Title:</label>
                            <input type="text" data-field="title" value="${release.title || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Artist:</label>
                            <input type="text" data-field="artist" value="${release.artist || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Release Date:</label>
                            <input type="text" data-field="releaseDate" value="${release.releaseDate || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Label:</label>
                            <input type="text" data-field="label" value="${release.label || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Genre:</label>
                            <input type="text" data-field="genre" value="${release.genre || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Format:</label>
                            <select data-field="format">
                                <option value="Digital" ${release.format === 'Digital' ? 'selected' : ''}>Digital</option>
                                <option value="Vinyl" ${release.format === 'Vinyl' ? 'selected' : ''}>Vinyl</option>
                                <option value="CD" ${release.format === 'CD' ? 'selected' : ''}>CD</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Purchase URL:</label>
                            <input type="url" data-field="purchaseUrl" value="${release.purchaseUrl || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Stream URL:</label>
                            <input type="url" data-field="streamUrl" value="${release.streamUrl || ''}" />
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    renderSocialTab() {
        const social = this.currentConfig.social || [];
        let html = `
            <div class="admin-form-section">
                <div class="section-header">
                    <h3>Social Links</h3>
                    <button class="admin-btn add-btn" onclick="adminSystem.addSocialLink()">+ ADD SOCIAL LINK</button>
                </div>
        `;
        
        social.forEach((link, index) => {
            html += `
                <div class="social-form" data-index="${index}">
                    <div class="member-header">
                        <h4>Social Link ${index + 1}</h4>
                        <button class="admin-btn delete-btn" onclick="adminSystem.removeSocialLink(${index})">🗑️</button>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Platform:</label>
                            <select data-field="platform">
                                <option value="Instagram" ${link.platform === 'Instagram' ? 'selected' : ''}>Instagram</option>
                                <option value="Facebook" ${link.platform === 'Facebook' ? 'selected' : ''}>Facebook</option>
                                <option value="Twitter" ${link.platform === 'Twitter' ? 'selected' : ''}>Twitter</option>
                                <option value="SoundCloud" ${link.platform === 'SoundCloud' ? 'selected' : ''}>SoundCloud</option>
                                <option value="Spotify" ${link.platform === 'Spotify' ? 'selected' : ''}>Spotify</option>
                                <option value="YouTube" ${link.platform === 'YouTube' ? 'selected' : ''}>YouTube</option>
                                <option value="Bandcamp" ${link.platform === 'Bandcamp' ? 'selected' : ''}>Bandcamp</option>
                                <option value="Mixcloud" ${link.platform === 'Mixcloud' ? 'selected' : ''}>Mixcloud</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Username:</label>
                            <input type="text" data-field="username" value="${link.username || ''}" />
                        </div>
                        <div class="form-group">
                            <label>URL:</label>
                            <input type="url" data-field="url" value="${link.url || ''}" />
                        </div>
                        <div class="form-group">
                            <label>Active:</label>
                            <select data-field="active">
                                <option value="true" ${link.active === true ? 'selected' : ''}>Yes</option>
                                <option value="false" ${link.active === false ? 'selected' : ''}>No</option>
                            </select>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    renderBookingsTab() {
        const { bookings } = this.currentConfig;
        let html = `
            <div class="admin-form-section">
                <div class="section-header">
                    <h3>Bookings</h3>
                    <button class="admin-btn add-btn" onclick="adminSystem.addBooking()">+ ADD BOOKING</button>
                </div>
        `;
        
        bookings.forEach((booking, index) => {
            html += `
                <div class="booking-form" data-index="${index}">
                    <div class="member-header">
                        <h4>Booking ${index + 1}</h4>
                        <button class="admin-btn delete-btn" onclick="adminSystem.removeBooking(${index})">🗑️</button>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Date:</label>
                            <input type="text" data-field="date" value="${booking.date}" />
                        </div>
                        <div class="form-group">
                            <label>Venue:</label>
                            <input type="text" data-field="venue" value="${booking.venue}" />
                        </div>
                        <div class="form-group">
                            <label>Location:</label>
                            <input type="text" data-field="location" value="${booking.location}" />
                        </div>
                        <div class="form-group">
                            <label>Type:</label>
                            <select data-field="type">
                                <option value="CLUB" ${booking.type === 'CLUB' ? 'selected' : ''}>Club</option>
                                <option value="WAREHOUSE" ${booking.type === 'WAREHOUSE' ? 'selected' : ''}>Warehouse</option>
                                <option value="FESTIVAL" ${booking.type === 'FESTIVAL' ? 'selected' : ''}>Festival</option>
                                <option value="OUTDOOR" ${booking.type === 'OUTDOOR' ? 'selected' : ''}>Outdoor</option>
                                <option value="PRIVATE" ${booking.type === 'PRIVATE' ? 'selected' : ''}>Private</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Status:</label>
                            <select data-field="status">
                                <option value="confirmed" ${booking.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
                                <option value="pending" ${booking.status === 'pending' ? 'selected' : ''}>Pending</option>
                                <option value="cancelled" ${booking.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                            </select>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        return html;
    }
    
    renderContactTab() {
        const { contact } = this.currentConfig;
        return `
            <div class="admin-form-section">
                <h3>Contact Information</h3>
                <div class="contact-sections">
                    <div class="contact-section">
                        <h4>Bookings</h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Email:</label>
                                <input type="email" id="bookingsEmail" value="${contact.bookings.email}" />
                            </div>
                            <div class="form-group">
                                <label>Phone:</label>
                                <input type="text" id="bookingsPhone" value="${contact.bookings.phone}" />
                            </div>
                        </div>
                    </div>
                    
                    <div class="contact-section">
                        <h4>Management</h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Email:</label>
                                <input type="email" id="managementEmail" value="${contact.management.email}" />
                            </div>
                            <div class="form-group">
                                <label>Company:</label>
                                <input type="text" id="managementCompany" value="${contact.management.company}" />
                            </div>
                        </div>
                    </div>
                    
                    <div class="contact-section">
                        <h4>Press</h4>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Email:</label>
                                <input type="email" id="pressEmail" value="${contact.press.email}" />
                            </div>
                            <div class="form-group">
                                <label>Note:</label>
                                <input type="text" id="pressNote" value="${contact.press.note}" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    setupTabEventListeners() {
        // Add event listeners for form inputs to update config in real-time
        const inputs = document.querySelectorAll('#adminContent input, #adminContent textarea, #adminContent select');
        inputs.forEach(input => {
            input.addEventListener('change', () => this.updateConfigFromForm());
        });
    }
    
    updateConfigFromForm() {
        if (!this.currentConfig) return;
        
        switch (this.currentTab) {
            case 'site-info':
                this.currentConfig.siteInfo.title = document.getElementById('siteTitle')?.value || '';
                this.currentConfig.siteInfo.logo = document.getElementById('siteLogo')?.value || '';
                this.currentConfig.siteInfo.copyright = document.getElementById('siteCopyright')?.value || '';
                this.currentConfig.siteInfo.description = document.getElementById('siteDescription')?.value || '';
                break;
                
            case 'members':
                const memberForms = document.querySelectorAll('.member-form');
                memberForms.forEach((form, index) => {
                    const inputs = form.querySelectorAll('input, select');
                    inputs.forEach(input => {
                        const field = input.getAttribute('data-field');
                        if (field && this.currentConfig.members[index]) {
                            let value = input.value;
                            if (field === 'yearsActive') value = parseInt(value);
                            this.currentConfig.members[index][field] = value;
                        }
                    });
                });
                break;
                
            case 'story':
                this.currentConfig.story.title = document.getElementById('storyTitle')?.value || '';
                this.currentConfig.story.content = document.getElementById('storyContent')?.value || '';
                break;
                
            case 'sets':
                if (!this.currentConfig.sets) this.currentConfig.sets = [];
                const setForms = document.querySelectorAll('.set-form');
                setForms.forEach((form, index) => {
                    const inputs = form.querySelectorAll('input, textarea, select');
                    inputs.forEach(input => {
                        const field = input.getAttribute('data-field');
                        if (field && this.currentConfig.sets[index]) {
                            this.currentConfig.sets[index][field] = input.value;
                        }
                    });
                });
                break;
                
            case 'releases':
                if (!this.currentConfig.releases) this.currentConfig.releases = [];
                const releaseForms = document.querySelectorAll('.release-form');
                releaseForms.forEach((form, index) => {
                    const inputs = form.querySelectorAll('input, select');
                    inputs.forEach(input => {
                        const field = input.getAttribute('data-field');
                        if (field && this.currentConfig.releases[index]) {
                            this.currentConfig.releases[index][field] = input.value;
                        }
                    });
                });
                break;
                
            case 'social':
                if (!this.currentConfig.social) this.currentConfig.social = [];
                const socialForms = document.querySelectorAll('.social-form');
                socialForms.forEach((form, index) => {
                    const inputs = form.querySelectorAll('input, select');
                    inputs.forEach(input => {
                        const field = input.getAttribute('data-field');
                        if (field && this.currentConfig.social[index]) {
                            let value = input.value;
                            if (field === 'active') value = value === 'true';
                            this.currentConfig.social[index][field] = value;
                        }
                    });
                });
                break;
                
            case 'bookings':
                const bookingForms = document.querySelectorAll('.booking-form');
                bookingForms.forEach((form, index) => {
                    const inputs = form.querySelectorAll('input, select');
                    inputs.forEach(input => {
                        const field = input.getAttribute('data-field');
                        if (field && this.currentConfig.bookings[index]) {
                            this.currentConfig.bookings[index][field] = input.value;
                        }
                    });
                });
                break;
                
            case 'contact':
                this.currentConfig.contact.bookings.email = document.getElementById('bookingsEmail')?.value || '';
                this.currentConfig.contact.bookings.phone = document.getElementById('bookingsPhone')?.value || '';
                this.currentConfig.contact.management.email = document.getElementById('managementEmail')?.value || '';
                this.currentConfig.contact.management.company = document.getElementById('managementCompany')?.value || '';
                this.currentConfig.contact.press.email = document.getElementById('pressEmail')?.value || '';
                this.currentConfig.contact.press.note = document.getElementById('pressNote')?.value || '';
                break;
        }
    }
    
    addMember() {
        this.currentConfig.members.push({
            id: `member_${Date.now()}`,
            name: 'New DJ',
            origin: 'City, State',
            specialty: 'Genre',
            equipment: 'Equipment',
            yearsActive: 1,
            status: 'online'
        });
        this.loadTabContent('members');
    }
    
    removeMember(index) {
        this.currentConfig.members.splice(index, 1);
        this.loadTabContent('members');
    }
    
    addDjSet() {
        if (!this.currentConfig.sets) this.currentConfig.sets = [];
        this.currentConfig.sets.push({
            title: 'New Set',
            date: '',
            duration: '',
            genre: '',
            url: '',
            description: ''
        });
        this.loadTabContent('sets');
    }
    
    removeDjSet(index) {
        if (this.currentConfig.sets) {
            this.currentConfig.sets.splice(index, 1);
            this.loadTabContent('sets');
        }
    }
    
    addRelease() {
        if (!this.currentConfig.releases) this.currentConfig.releases = [];
        this.currentConfig.releases.push({
            title: 'New Release',
            artist: '',
            releaseDate: '',
            label: '',
            genre: '',
            format: 'Digital',
            purchaseUrl: '',
            streamUrl: ''
        });
        this.loadTabContent('releases');
    }
    
    removeRelease(index) {
        if (this.currentConfig.releases) {
            this.currentConfig.releases.splice(index, 1);
            this.loadTabContent('releases');
        }
    }
    
    addSocialLink() {
        if (!this.currentConfig.social) this.currentConfig.social = [];
        this.currentConfig.social.push({
            platform: 'Instagram',
            username: '',
            url: '',
            active: true
        });
        this.loadTabContent('social');
    }
    
    removeSocialLink(index) {
        if (this.currentConfig.social) {
            this.currentConfig.social.splice(index, 1);
            this.loadTabContent('social');
        }
    }
    
    addBooking() {
        this.currentConfig.bookings.push({
            date: 'DD MMM YYYY',
            venue: 'VENUE NAME',
            location: 'CITY, STATE',
            type: 'CLUB',
            status: 'pending'
        });
        this.loadTabContent('bookings');
    }
    
    removeBooking(index) {
        this.currentConfig.bookings.splice(index, 1);
        this.loadTabContent('bookings');
    }
    
    async saveChanges() {
        if (!this.currentConfig) return;
        
        const saveBtn = document.getElementById('saveChanges');
        const originalText = saveBtn.textContent;
        
        saveBtn.textContent = '💾 SAVING...';
        saveBtn.disabled = true;
        
        try {
            // Update form data first
            this.updateConfigFromForm();
            
            // Save to localStorage
            localStorage.setItem('n4g-site-config', JSON.stringify(this.currentConfig));
            
            // Update the live site
            if (window.contentLoader) {
                window.contentLoader.config = this.currentConfig;
                window.contentLoader.updateSiteContent();
            }
            
            saveBtn.textContent = '✅ SAVED!';
            saveBtn.style.background = '#10b981';
            
            setTimeout(() => {
                saveBtn.textContent = originalText;
                saveBtn.style.background = '';
                saveBtn.disabled = false;
            }, 2000);
            
        } catch (error) {
            console.error('Save failed:', error);
            saveBtn.textContent = '❌ ERROR';
            saveBtn.style.background = '#ef4444';
            
            setTimeout(() => {
                saveBtn.textContent = originalText;
                saveBtn.style.background = '';
                saveBtn.disabled = false;
            }, 2000);
        }
    }
}

// Initialize admin system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.adminSystem = new AdminSystem();
});