class NeedForGrooveOS {
    constructor() {
        this.currentSection = 'home';
        this.soundsEnabled = true;
        this.glitchEnabled = true;
        this.crtScreenEnabled = true;
        this.menuOpen = false;
        this.audioContext = null;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.startRandomGlitches();
        this.startDualCursorBlink();
        this.loadUserSettings();
        this.initAudioContext();
    }
    
    initAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (error) {
            console.log('Audio context not available');
        }
    }
    
    setupEventListeners() {
        // Menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        const menuClose = document.querySelector('.menu-close');
        const sideMenu = document.querySelector('.side-menu');
        
        menuToggle?.addEventListener('click', () => this.toggleMenu());
        menuClose?.addEventListener('click', () => this.closeMenu());
        
        // Close menu on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.menuOpen) {
                this.closeMenu();
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (this.menuOpen && !sideMenu.contains(e.target) && !menuToggle.contains(e.target)) {
                this.closeMenu();
            }
        });
        
        // Navigation links
        const navLinks = document.querySelectorAll('[data-section]');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                this.navigateToSection(section);
                if (this.menuOpen) this.closeMenu();
            });
        });
        
        // Expand/Collapse controls
        this.setupExpandCollapse();
        
        // Toggle switches
        this.setupToggleSwitches();
        
        // Set thumbnails
        this.setupSetThumbnails();
        
        // Release items
        this.setupReleaseItems();
        
        // Mix items
        this.setupMixItems();
        
        // Member cards
        this.setupMemberCards();
    }
    
    toggleMenu() {
        if (this.menuOpen) {
            this.closeMenu();
        } else {
            this.openMenu();
        }
    }
    
    openMenu() {
        const sideMenu = document.querySelector('.side-menu');
        sideMenu.setAttribute('data-state', 'open');
        this.menuOpen = true;
        
        // Animate menu items
        const menuItems = sideMenu.querySelectorAll('.menu-link, .social-link');
        menuItems.forEach((item, index) => {
            item.style.animation = `slideInFromRight 0.3s ease-out ${index * 0.05}s both`;
        });
        
        this.playSound('menu-open');
    }
    
    closeMenu() {
        const sideMenu = document.querySelector('.side-menu');
        sideMenu.setAttribute('data-state', 'closed');
        this.menuOpen = false;
        
        this.playSound('menu-close');
    }
    
    navigateToSection(sectionName) {
        // Hide all sections
        const sections = document.querySelectorAll('.content-section');
        sections.forEach(section => section.classList.remove('active'));
        
        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
        }
        
        // Update file tree
        const treeItems = document.querySelectorAll('.tree-item');
        treeItems.forEach(item => item.classList.remove('active'));
        
        const targetTreeItem = document.querySelector(`[data-section="${sectionName}"]`);
        if (targetTreeItem) {
            targetTreeItem.classList.add('active');
        }
        
        this.currentSection = sectionName;
        this.playSound('nav-click');
    }
    
    setupExpandCollapse() {
        const expandButtons = document.querySelectorAll('.expand-btn');
        const collapseButtons = document.querySelectorAll('.collapse-btn');
        
        expandButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const target = e.target.getAttribute('data-target');
                this.expandSection(target);
                this.playSound('expand');
            });
        });
        
        collapseButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const target = e.target.getAttribute('data-target');
                this.collapseSection(target);
                this.playSound('collapse');
            });
        });
    }
    
    expandSection(target) {
        if (target === 'socials') {
            const socialLinks = document.querySelector('.social-links');
            socialLinks?.setAttribute('data-expanded', 'true');
        } else if (target === 'settings') {
            const settingsPanel = document.querySelector('.settings-panel');
            settingsPanel?.setAttribute('data-expanded', 'true');
        }
    }
    
    collapseSection(target) {
        if (target === 'socials') {
            const socialLinks = document.querySelector('.social-links');
            socialLinks?.setAttribute('data-expanded', 'false');
        } else if (target === 'settings') {
            const settingsPanel = document.querySelector('.settings-panel');
            settingsPanel?.setAttribute('data-expanded', 'false');
        }
    }
    
    setupToggleSwitches() {
        const toggleButtons = document.querySelectorAll('.toggle-switch button');
        
        toggleButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const parent = e.target.parentElement;
                const siblings = parent.querySelectorAll('button');
                
                // Remove active class from all siblings
                siblings.forEach(sibling => sibling.classList.remove('active'));
                
                // Add active class to clicked button
                e.target.classList.add('active');
                
                // Handle specific toggle actions
                this.handleToggleAction(e.target);
                
                this.playSound('toggle');
            });
        });
    }
    
    handleToggleAction(button) {
        const settingItem = button.closest('.setting-item');
        const label = settingItem.querySelector('.setting-label').textContent;
        const value = button.textContent;
        
        switch (label) {
            case 'Sounds:':
                this.soundsEnabled = value === 'ON';
                localStorage.setItem('n4g-sounds', this.soundsEnabled);
                break;
            case 'BG Glitches:':
                this.glitchEnabled = value === 'ON';
                localStorage.setItem('n4g-glitches', this.glitchEnabled);
                break;
            case 'CRT Screen:':
                this.crtScreenEnabled = value === 'ON';
                this.toggleCRTScreen(this.crtScreenEnabled);
                localStorage.setItem('n4g-crt-screen', this.crtScreenEnabled);
                break;
            case 'Cookies:':
                const cookiesEnabled = value === 'ON';
                localStorage.setItem('n4g-cookies', cookiesEnabled);
                break;
        }
    }
    
    toggleCRTScreen(enabled) {
        const scanlinesOverlay = document.querySelector('.scanlines-overlay');
        if (scanlinesOverlay) {
            scanlinesOverlay.style.display = enabled ? 'block' : 'none';
        }
    }
    
    setupSetThumbnails() {
        const setItems = document.querySelectorAll('.set-item');
        
        setItems.forEach(item => {
            item.addEventListener('click', () => {
                this.playSound('set-click');
                const setTitle = item.querySelector('.set-title').textContent;
                console.log('Playing set:', setTitle);
                // Here you would implement set playback
            });
            
            item.addEventListener('mouseenter', () => {
                this.playSound('hover');
            });
        });
    }
    
    setupReleaseItems() {
        const releaseItems = document.querySelectorAll('.release-item');
        
        releaseItems.forEach(item => {
            item.addEventListener('click', () => {
                this.playSound('release-click');
                const releaseTitle = item.querySelector('.release-title').textContent;
                console.log('Opening release:', releaseTitle);
                // Here you would implement release details
            });
            
            item.addEventListener('mouseenter', () => {
                this.playSound('hover');
            });
        });
    }
    
    setupMixItems() {
        const mixItems = document.querySelectorAll('.mix-item');
        
        mixItems.forEach(item => {
            item.addEventListener('click', () => {
                this.playSound('mix-click');
                const mixName = item.querySelector('.mix-name').textContent;
                console.log('Opening mix:', mixName);
                // Here you would implement mix playback
            });
            
            item.addEventListener('mouseenter', () => {
                this.playSound('hover');
            });
        });
    }
    
    setupMemberCards() {
        const memberCards = document.querySelectorAll('.member-card');
        
        memberCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                this.playSound('hover');
            });
        });
    }
    
    startRandomGlitches() {
        if (!this.glitchEnabled) return;
        
        const triggerGlitch = () => {
            if (!this.glitchEnabled) return;
            
            const glitchOverlay = document.querySelector('.glitch-overlay');
            if (glitchOverlay) {
                glitchOverlay.classList.add('active');
                
                setTimeout(() => {
                    glitchOverlay.classList.remove('active');
                }, 300);
            }
            
            // Schedule next glitch
            const nextGlitchTime = Math.random() * 15000 + 8000; // 8-23 seconds
            setTimeout(triggerGlitch, nextGlitchTime);
        };
        
        // Start first glitch after random delay
        const initialDelay = Math.random() * 5000 + 3000; // 3-8 seconds
        setTimeout(triggerGlitch, initialDelay);
    }
    
    startDualCursorBlink() {
        const cursor1 = document.querySelector('.cursor-1');
        const cursor2 = document.querySelector('.cursor-2');
        
        if (!cursor1 || !cursor2) return;
        
        // Alternating blink pattern for the duo
        setInterval(() => {
            cursor1.style.opacity = cursor1.style.opacity === '0' ? '1' : '0';
        }, 800);
        
        setInterval(() => {
            cursor2.style.opacity = cursor2.style.opacity === '0' ? '1' : '0';
        }, 800);
    }
    
    playSound(soundType) {
        if (!this.soundsEnabled || !this.audioContext) return;
        
        try {
            // Resume audio context if suspended (required by browsers)
            if (this.audioContext.state === 'suspended') {
                this.audioContext.resume();
            }
            
            const now = this.audioContext.currentTime;
            
            switch (soundType) {
                case 'menu-open':
                    this.playChord([220, 277, 330], 0.4, 'sawtooth', now);
                    break;
                case 'menu-close':
                    this.playChord([330, 277, 220], 0.3, 'sawtooth', now);
                    break;
                case 'nav-click':
                    this.playBassHit(110, 0.15, now);
                    break;
                case 'hover':
                    // Back to original simple beep
                    this.playSimpleBeep(1000, 0.05, now);
                    break;
                case 'toggle':
                    this.playToggleSound(now);
                    break;
                case 'expand':
                    this.playRiser(440, 880, 0.2, now);
                    break;
                case 'collapse':
                    this.playRiser(880, 440, 0.2, now);
                    break;
                case 'set-click':
                    this.playKickDrum(now);
                    break;
                case 'release-click':
                    this.playSynthStab(now);
                    break;
                case 'mix-click':
                    this.playHiHat(now);
                    break;
            }
        } catch (error) {
            console.log('Audio playback error:', error);
        }
    }
    
    playSimpleBeep(frequency, duration, startTime) {
        // Original simple beep sound
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(frequency, startTime);
        oscillator.type = 'square';
        
        gainNode.gain.setValueAtTime(0.1, startTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + duration);
    }
    
    playChord(frequencies, duration, waveType = 'sine', startTime) {
        frequencies.forEach((freq, index) => {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            const filter = this.audioContext.createBiquadFilter();
            
            oscillator.connect(filter);
            filter.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            oscillator.frequency.setValueAtTime(freq, startTime);
            oscillator.type = waveType;
            
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(2000, startTime);
            filter.Q.setValueAtTime(1, startTime);
            
            gainNode.gain.setValueAtTime(0, startTime);
            gainNode.gain.linearRampToValueAtTime(0.1 / frequencies.length, startTime + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
            
            oscillator.start(startTime);
            oscillator.stop(startTime + duration);
        });
    }
    
    playBassHit(frequency, duration, startTime) {
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();
        
        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(frequency, startTime);
        oscillator.frequency.exponentialRampToValueAtTime(frequency * 0.5, startTime + duration);
        oscillator.type = 'sawtooth';
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(800, startTime);
        filter.frequency.exponentialRampToValueAtTime(200, startTime + duration);
        filter.Q.setValueAtTime(2, startTime);
        
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.3, startTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + duration);
    }
    
    playToggleSound(startTime) {
        // Two-tone toggle sound
        const freq1 = 660;
        const freq2 = 880;
        
        [freq1, freq2].forEach((freq, index) => {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            oscillator.frequency.setValueAtTime(freq, startTime + index * 0.05);
            oscillator.type = 'square';
            
            gainNode.gain.setValueAtTime(0, startTime + index * 0.05);
            gainNode.gain.linearRampToValueAtTime(0.1, startTime + index * 0.05 + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + index * 0.05 + 0.1);
            
            oscillator.start(startTime + index * 0.05);
            oscillator.stop(startTime + index * 0.05 + 0.1);
        });
    }
    
    playRiser(startFreq, endFreq, duration, startTime) {
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();
        
        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(startFreq, startTime);
        oscillator.frequency.exponentialRampToValueAtTime(endFreq, startTime + duration);
        oscillator.type = 'sawtooth';
        
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(startFreq * 2, startTime);
        filter.frequency.exponentialRampToValueAtTime(endFreq * 2, startTime + duration);
        filter.Q.setValueAtTime(3, startTime);
        
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.15, startTime + duration * 0.3);
        gainNode.gain.linearRampToValueAtTime(0.001, startTime + duration);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + duration);
    }
    
    playKickDrum(startTime) {
        // Kick drum with sub bass
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();
        
        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(60, startTime);
        oscillator.frequency.exponentialRampToValueAtTime(30, startTime + 0.1);
        oscillator.type = 'sine';
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(200, startTime);
        filter.Q.setValueAtTime(1, startTime);
        
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.4, startTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + 0.2);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + 0.2);
        
        // Add click for punch
        this.playClick(startTime);
    }
    
    playClick(startTime) {
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(2000, startTime);
        oscillator.type = 'square';
        
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.2, startTime + 0.001);
        gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + 0.01);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + 0.01);
    }
    
    playSynthStab(startTime) {
        // Chord stab with filter sweep
        const frequencies = [220, 277, 330, 415]; // Am7 chord
        
        frequencies.forEach((freq, index) => {
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            const filter = this.audioContext.createBiquadFilter();
            
            oscillator.connect(filter);
            filter.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            oscillator.frequency.setValueAtTime(freq, startTime);
            oscillator.type = 'sawtooth';
            
            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(200, startTime);
            filter.frequency.exponentialRampToValueAtTime(2000, startTime + 0.1);
            filter.frequency.exponentialRampToValueAtTime(400, startTime + 0.3);
            filter.Q.setValueAtTime(5, startTime);
            
            gainNode.gain.setValueAtTime(0, startTime);
            gainNode.gain.linearRampToValueAtTime(0.08, startTime + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + 0.3);
            
            oscillator.start(startTime);
            oscillator.stop(startTime + 0.3);
        });
    }
    
    playHiHat(startTime) {
        // High frequency noise burst
        const bufferSize = this.audioContext.sampleRate * 0.1;
        const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / bufferSize, 2);
        }
        
        const source = this.audioContext.createBufferSource();
        const gainNode = this.audioContext.createGain();
        const filter = this.audioContext.createBiquadFilter();
        
        source.buffer = buffer;
        source.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(8000, startTime);
        filter.Q.setValueAtTime(1, startTime);
        
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.2, startTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + 0.1);
        
        source.start(startTime);
    }
    
    loadUserSettings() {
        // Load saved settings from localStorage
        const savedSounds = localStorage.getItem('n4g-sounds');
        const savedGlitches = localStorage.getItem('n4g-glitches');
        const savedCRTScreen = localStorage.getItem('n4g-crt-screen');
        const savedCookies = localStorage.getItem('n4g-cookies');
        
        if (savedSounds !== null) {
            this.soundsEnabled = savedSounds === 'true';
            this.updateToggleButton('Sounds:', this.soundsEnabled ? 'ON' : 'OFF');
        }
        
        if (savedGlitches !== null) {
            this.glitchEnabled = savedGlitches === 'true';
            this.updateToggleButton('BG Glitches:', this.glitchEnabled ? 'ON' : 'OFF');
        }
        
        if (savedCRTScreen !== null) {
            this.crtScreenEnabled = savedCRTScreen === 'true';
            this.toggleCRTScreen(this.crtScreenEnabled);
            this.updateToggleButton('CRT Screen:', this.crtScreenEnabled ? 'ON' : 'OFF');
        }
        
        if (savedCookies !== null) {
            const cookiesEnabled = savedCookies === 'true';
            this.updateToggleButton('Cookies:', cookiesEnabled ? 'ON' : 'OFF');
        }
    }
    
    updateToggleButton(label, value) {
        const settingItems = document.querySelectorAll('.setting-item');
        
        settingItems.forEach(item => {
            const itemLabel = item.querySelector('.setting-label').textContent;
            if (itemLabel === label) {
                const buttons = item.querySelectorAll('.toggle-switch button');
                buttons.forEach(btn => {
                    btn.classList.remove('active');
                    if (btn.textContent === value) {
                        btn.classList.add('active');
                    }
                });
            }
        });
    }
}

// Add CSS animation for menu items
const style = document.createElement('style');
style.textContent = `
@keyframes slideInFromRight {
    from {
        transform: translateX(100px);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
`;
document.head.appendChild(style);

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.n4gOS = new NeedForGrooveOS();
});

// Add some additional interactive elements
document.addEventListener('DOMContentLoaded', () => {
    // Add hover effects to various elements
    const interactiveElements = document.querySelectorAll(
        '.tree-item, .booking-row:not(.header-row), .podcast-item, .contact-section'
    );
    
    interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
            if (window.n4gOS && window.n4gOS.soundsEnabled) {
                window.n4gOS.playSound('hover');
            }
        });
    });
    
    // Add typing effect to terminal
    const terminalContent = document.querySelector('.terminal-content');
    if (terminalContent) {
        // Simulate typing effect for boot sequence
        const bootLines = terminalContent.querySelectorAll('.boot-line');
        bootLines.forEach((line, index) => {
            line.style.opacity = '0';
            setTimeout(() => {
                line.style.opacity = '1';
                line.style.animation = 'typewriter 0.5s steps(40, end)';
            }, index * 300);
        });
    }
    
    // Add newsletter form submission
    const subscribeBtn = document.querySelector('.subscribe-btn');
    const emailInput = document.querySelector('.email-input');
    
    if (subscribeBtn && emailInput) {
        subscribeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const email = emailInput.value.trim();
            
            if (email && email.includes('@')) {
                // Simulate subscription
                subscribeBtn.textContent = 'SUBSCRIBED!';
                subscribeBtn.style.background = 'var(--blue-primary)';
                subscribeBtn.style.color = 'var(--bg-primary)';
                emailInput.value = '';
                
                setTimeout(() => {
                    subscribeBtn.textContent = 'SUBSCRIBE';
                    subscribeBtn.style.background = 'transparent';
                    subscribeBtn.style.color = 'var(--blue-primary)';
                }, 2000);
                
                if (window.n4gOS) {
                    window.n4gOS.playSound('release-click');
                }
            } else {
                // Show error state
                emailInput.style.borderColor = '#ff0040';
                setTimeout(() => {
                    emailInput.style.borderColor = 'var(--blue-secondary)';
                }, 1000);
            }
        });
        
        emailInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                subscribeBtn.click();
            }
        });
    }
    
    // Booking status animations
    const bookingStatuses = document.querySelectorAll('.booking-status');
    bookingStatuses.forEach(status => {
        if (status.classList.contains('confirmed')) {
            status.addEventListener('mouseenter', () => {
                status.style.textShadow = '0 0 8px var(--blue-glow)';
            });
            status.addEventListener('mouseleave', () => {
                status.style.textShadow = 'none';
            });
        }
    });
    
    // Member status indicator pulse
    const statusIndicators = document.querySelectorAll('.status-indicator');
    statusIndicators.forEach(indicator => {
        setInterval(() => {
            indicator.style.transform = indicator.style.transform === 'scale(1.2)' ? 'scale(1)' : 'scale(1.2)';
        }, 2000);
    });
});

// Add additional CSS for typewriter effect
const typewriterStyle = document.createElement('style');
typewriterStyle.textContent = `
@keyframes typewriter {
    from { width: 0; }
    to { width: 100%; }
}

.boot-line {
    overflow: hidden;
    white-space: nowrap;
    border-right: 2px solid var(--blue-primary);
    animation: blink-caret 1s step-end infinite;
}

@keyframes blink-caret {
    from, to { border-color: transparent; }
    50% { border-color: var(--blue-primary); }
}
`;
document.head.appendChild(typewriterStyle);