import React, { useState, useEffect } from 'react';
import { AdminLogin } from './components/AdminLogin';
import { AdminPanel } from './components/AdminPanel';

function App() {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  useEffect(() => {
    // Check if user is already authenticated
    const session = localStorage.getItem('n4g-admin-session');
    if (session === 'authenticated') {
      setIsAdminAuthenticated(true);
    }
    setIsCheckingAuth(false);
  }, []);

  const handleLogin = (success: boolean) => {
    setIsAdminAuthenticated(success);
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-blue-400 font-mono">Initializing system...</div>
      </div>
    );
  }

  // Check if we're in admin mode (URL contains /admin)
  const isAdminMode = window.location.pathname.includes('/admin') || window.location.hash.includes('admin');

  if (isAdminMode) {
    if (!isAdminAuthenticated) {
      return <AdminLogin onLogin={handleLogin} />;
    }
    return <AdminPanel onLogout={handleLogout} />;
  }

  // Regular site - redirect to the existing HTML site
  window.location.href = '/index.html';
  return null;
}

export default App;