import React, { useState } from 'react';
import { Lock, Eye, EyeOff } from 'lucide-react';

interface AdminLoginProps {
  onLogin: (success: boolean) => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simulate authentication delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // Simple hardcoded credentials (in production, this would be server-side)
    if (username === 'n4gadmin' && password === 'groove2024!') {
      localStorage.setItem('n4g-admin-session', 'authenticated');
      onLogin(true);
    } else {
      setError('Invalid credentials. Access denied.');
      onLogin(false);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Terminal-style login window */}
        <div className="bg-gray-900 border border-blue-500 rounded-lg overflow-hidden shadow-2xl">
          {/* Window header */}
          <div className="bg-gray-800 px-4 py-2 border-b border-blue-500">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
              <span className="ml-2 text-blue-400 text-sm font-mono">admin@n4g-system</span>
            </div>
          </div>

          {/* Login form */}
          <div className="p-6">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-500/20 rounded-full mb-4">
                <Lock className="w-8 h-8 text-blue-400" />
              </div>
              <h1 className="text-2xl font-bold text-blue-400 font-mono mb-2">
                N4G ADMIN ACCESS
              </h1>
              <p className="text-gray-400 text-sm font-mono">
                Authorized personnel only
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-blue-400 text-sm font-mono mb-2">
                  USERNAME:
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-3 py-2 bg-black border border-gray-600 rounded text-white font-mono focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                  placeholder="Enter username"
                  required
                />
              </div>

              <div>
                <label className="block text-blue-400 text-sm font-mono mb-2">
                  PASSWORD:
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-black border border-gray-600 rounded text-white font-mono focus:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400 pr-10"
                    placeholder="Enter password"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-blue-400"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="bg-red-900/50 border border-red-500 rounded p-3">
                  <p className="text-red-400 text-sm font-mono">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white font-mono py-2 px-4 rounded transition-colors duration-200 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    AUTHENTICATING...
                  </>
                ) : (
                  'ACCESS SYSTEM'
                )}
              </button>
            </form>

            <div className="mt-6 pt-4 border-t border-gray-700">
              <p className="text-gray-500 text-xs font-mono text-center">
                Security Level: MAXIMUM<br />
                Unauthorized access is prohibited
              </p>
            </div>
          </div>
        </div>

        {/* Demo credentials info */}
        <div className="mt-4 bg-gray-800/50 border border-gray-600 rounded p-3">
          <p className="text-gray-400 text-xs font-mono text-center">
            Demo Credentials:<br />
            Username: <span className="text-blue-400">n4gadmin</span><br />
            Password: <span className="text-blue-400">groove2024!</span>
          </p>
        </div>
      </div>
    </div>
  );
};