import React, { useState, useEffect } from 'react';
import { Save, LogOut, Edit3, Plus, Trash2, Upload, Eye, EyeOff, Image, Music, Calendar, Users, Settings, Globe, Mail, FileText, BarChart3, Download, Copy, RefreshCw } from 'lucide-react';

interface SiteConfig {
  siteInfo: {
    title: string;
    logo: string;
    copyright: string;
    description: string;
    tagline: string;
    keywords: string[];
    favicon: string;
    ogImage: string;
  };
  members: Array<{
    id: string;
    name: string;
    origin: string;
    specialty: string;
    equipment: string;
    yearsActive: number;
    status: string;
    bio: string;
    profileImage: string;
    socialLinks: { platform: string; url: string }[];
  }>;
  story: {
    title: string;
    content: string;
    timeline: Array<{
      year: string;
      event: string;
      description: string;
    }>;
  };
  djSets: Array<{
    title: string;
    details: string;
    duration: string;
    thumbnail: string;
    url: string;
    genre: string;
    venue: string;
    date: string;
    description: string;
    tracklist: string[];
    downloads: number;
    plays: number;
  }>;
  podcasts: Array<{
    episode: string;
    title: string;
    date: string;
    description: string;
    duration: string;
    url: string;
    thumbnail: string;
  }>;
  bookings: Array<{
    date: string;
    venue: string;
    location: string;
    type: string;
    status: string;
    ticketUrl: string;
    price: string;
    capacity: string;
    description: string;
  }>;
  releases: Array<{
    title: string;
    label: string;
    year: string;
    cover: string;
    url: string;
    genre: string;
    format: string;
    catalogNumber: string;
    description: string;
    tracks: Array<{
      title: string;
      duration: string;
      preview: string;
    }>;
  }>;
  mixes: Array<{
    name: string;
    description: string;
    icon: string;
    url: string;
    category: string;
    frequency: string;
  }>;
  contact: {
    bookings: { email: string; phone: string; name: string };
    management: { email: string; company: string; name: string };
    press: { email: string; note: string; name: string };
    technical: { email: string; name: string };
  };
  socialLinks: Array<{
    name: string;
    url: string;
    username: string;
    followers: string;
    active: boolean;
  }>;
  seo: {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
    canonicalUrl: string;
    robots: string;
  };
  analytics: {
    googleAnalytics: string;
    facebookPixel: string;
    hotjar: string;
  };
  appearance: {
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    fontFamily: string;
    logoStyle: string;
    backgroundPattern: string;
  };
  features: {
    newsletter: boolean;
    comments: boolean;
    downloads: boolean;
    merchandise: boolean;
    booking: boolean;
    blog: boolean;
  };
}

interface AdminPanelProps {
  onLogout: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onLogout }) => {
  const [config, setConfig] = useState<SiteConfig | null>(null);
  const [activeTab, setActiveTab] = useState('site');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDirty, setIsDirty] = useState(false);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const response = await fetch('/content/site-config.json');
      const data = await response.json();
      
      // Merge with default structure to ensure all fields exist
      const defaultConfig = {
        siteInfo: {
          title: '',
          logo: '',
          copyright: '',
          description: '',
          tagline: '',
          keywords: [],
          favicon: '',
          ogImage: '',
        },
        members: [],
        story: {
          title: '',
          content: '',
          timeline: [],
        },
        djSets: [],
        podcasts: [],
        bookings: [],
        releases: [],
        mixes: [],
        contact: {
          bookings: { email: '', phone: '', name: '' },
          management: { email: '', company: '', name: '' },
          press: { email: '', note: '', name: '' },
          technical: { email: '', name: '' },
        },
        socialLinks: [],
        seo: {
          metaTitle: '',
          metaDescription: '',
          keywords: [],
          canonicalUrl: '',
          robots: 'index, follow',
        },
        analytics: {
          googleAnalytics: '',
          facebookPixel: '',
          hotjar: '',
        },
        appearance: {
          primaryColor: '#00D4FF',
          secondaryColor: '#0099CC',
          accentColor: '#FF6B35',
          fontFamily: 'JetBrains Mono',
          logoStyle: 'text',
          backgroundPattern: 'scanlines',
        },
        features: {
          newsletter: true,
          comments: false,
          downloads: true,
          merchandise: false,
          booking: true,
          blog: false,
        },
      };
      
      setConfig({ ...defaultConfig, ...data });
    } catch (error) {
      console.error('Failed to load config:', error);
    }
  };

  const saveConfig = async () => {
    if (!config) return;
    
    setIsSaving(true);
    try {
      localStorage.setItem('n4g-site-config', JSON.stringify(config));
      
      if (window.contentLoader) {
        window.contentLoader.config = config;
        window.contentLoader.updateSiteContent();
      }
      
      setSaveStatus('success');
      setIsDirty(false);
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (error) {
      setSaveStatus('error');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
    setIsSaving(false);
  };

  const handleLogout = () => {
    if (isDirty) {
      if (!confirm('You have unsaved changes. Are you sure you want to logout?')) {
        return;
      }
    }
    localStorage.removeItem('n4g-admin-session');
    onLogout();
  };

  const updateConfig = (path: string[], value: any) => {
    if (!config) return;
    
    const newConfig = { ...config };
    let current: any = newConfig;
    
    for (let i = 0; i < path.length - 1; i++) {
      current = current[path[i]];
    }
    
    current[path[path.length - 1]] = value;
    setConfig(newConfig);
    setIsDirty(true);
  };

  const addArrayItem = (arrayPath: string[], template: any) => {
    if (!config) return;
    
    const newConfig = { ...config };
    let current: any = newConfig;
    
    for (const key of arrayPath) {
      current = current[key];
    }
    
    current.push({ ...template });
    setConfig(newConfig);
    setIsDirty(true);
  };

  const removeArrayItem = (arrayPath: string[], index: number) => {
    if (!config) return;
    
    const newConfig = { ...config };
    let current: any = newConfig;
    
    for (const key of arrayPath) {
      current = current[key];
    }
    
    current.splice(index, 1);
    setConfig(newConfig);
    setIsDirty(true);
  };

  const exportConfig = () => {
    if (!config) return;
    
    const dataStr = JSON.stringify(config, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'n4g-site-config.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const importConfig = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedConfig = JSON.parse(e.target?.result as string);
        setConfig(importedConfig);
        setIsDirty(true);
      } catch (error) {
        alert('Invalid JSON file');
      }
    };
    reader.readAsText(file);
  };

  const duplicateItem = (arrayPath: string[], index: number) => {
    if (!config) return;
    
    const newConfig = { ...config };
    let current: any = newConfig;
    
    for (const key of arrayPath) {
      current = current[key];
    }
    
    const itemToDuplicate = { ...current[index] };
    if (itemToDuplicate.id) {
      itemToDuplicate.id = `${itemToDuplicate.id}_copy_${Date.now()}`;
    }
    if (itemToDuplicate.title) {
      itemToDuplicate.title = `${itemToDuplicate.title} (Copy)`;
    }
    
    current.splice(index + 1, 0, itemToDuplicate);
    setConfig(newConfig);
    setIsDirty(true);
  };

  if (!config) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-blue-400 font-mono">Loading admin panel...</div>
      </div>
    );
  }

  const tabs = [
    { id: 'site', label: 'Site Info', icon: Globe },
    { id: 'members', label: 'DJ Members', icon: Users },
    { id: 'story', label: 'Story & Timeline', icon: FileText },
    { id: 'sets', label: 'DJ Sets', icon: Music },
    { id: 'podcasts', label: 'Podcasts', icon: Music },
    { id: 'bookings', label: 'Bookings', icon: Calendar },
    { id: 'releases', label: 'Releases', icon: Music },
    { id: 'mixes', label: 'Mix Series', icon: Music },
    { id: 'contact', label: 'Contact', icon: Mail },
    { id: 'social', label: 'Social Links', icon: Globe },
    { id: 'seo', label: 'SEO & Meta', icon: BarChart3 },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'appearance', label: 'Appearance', icon: Settings },
    { id: 'features', label: 'Features', icon: Settings },
  ];

  const filteredTabs = tabs.filter(tab => 
    tab.label.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Admin Header */}
      <header className="bg-gray-900 border-b border-blue-500 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold text-blue-400 font-mono">N4G ADMIN PANEL</h1>
            {isDirty && (
              <span className="text-yellow-400 font-mono text-sm">● UNSAVED CHANGES</span>
            )}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPreviewMode(!isPreviewMode)}
                className={`flex items-center gap-2 px-3 py-1 rounded text-sm font-mono transition-colors ${
                  isPreviewMode 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {isPreviewMode ? <EyeOff size={16} /> : <Eye size={16} />}
                {isPreviewMode ? 'EDIT MODE' : 'PREVIEW'}
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={exportConfig}
              className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded font-mono text-sm transition-colors"
            >
              <Download size={16} />
              EXPORT
            </button>
            
            <label className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded font-mono text-sm transition-colors cursor-pointer">
              <Upload size={16} />
              IMPORT
              <input
                type="file"
                accept=".json"
                onChange={importConfig}
                className="hidden"
              />
            </label>
            
            <button
              onClick={saveConfig}
              disabled={isSaving}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 px-4 py-2 rounded font-mono text-sm transition-colors"
            >
              <Save size={16} />
              {isSaving ? 'SAVING...' : 'SAVE CHANGES'}
            </button>
            
            {saveStatus === 'success' && (
              <span className="text-green-400 font-mono text-sm">✓ SAVED</span>
            )}
            {saveStatus === 'error' && (
              <span className="text-red-400 font-mono text-sm">✗ ERROR</span>
            )}
            
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700 px-4 py-2 rounded font-mono text-sm transition-colors"
            >
              <LogOut size={16} />
              LOGOUT
            </button>
          </div>
        </div>
      </header>

      {/* Admin Content */}
      {isPreviewMode ? (
        <div className="p-6">
          <div className="bg-gray-800 border border-blue-500 rounded-lg p-4 mb-4">
            <h2 className="text-blue-400 font-mono mb-2">PREVIEW MODE</h2>
            <p className="text-gray-300 text-sm">
              Your changes are being applied to the live site. Switch back to Edit Mode to continue making changes.
            </p>
          </div>
          <iframe 
            src="/" 
            className="w-full h-screen border border-gray-600 rounded-lg"
            title="Site Preview"
          />
        </div>
      ) : (
        <div className="flex">
          {/* Sidebar Navigation */}
          <nav className="w-64 bg-gray-900 border-r border-gray-700 min-h-screen p-4">
            <div className="mb-4">
              <input
                type="text"
                placeholder="Search tabs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono text-sm"
              />
            </div>
            
            <div className="space-y-2">
              {filteredTabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full text-left px-3 py-2 rounded font-mono text-sm transition-colors flex items-center gap-2 ${
                      activeTab === tab.id
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    <Icon size={16} />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </nav>

          {/* Main Content */}
          <main className="flex-1 p-6 overflow-y-auto">
            {activeTab === 'site' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-blue-400 font-mono">SITE INFORMATION</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">SITE TITLE</label>
                    <input
                      type="text"
                      value={config.siteInfo.title}
                      onChange={(e) => updateConfig(['siteInfo', 'title'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">LOGO TEXT</label>
                    <input
                      type="text"
                      value={config.siteInfo.logo}
                      onChange={(e) => updateConfig(['siteInfo', 'logo'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">TAGLINE</label>
                    <input
                      type="text"
                      value={config.siteInfo.tagline || ''}
                      onChange={(e) => updateConfig(['siteInfo', 'tagline'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                      placeholder="Short catchy tagline"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">COPYRIGHT</label>
                    <input
                      type="text"
                      value={config.siteInfo.copyright}
                      onChange={(e) => updateConfig(['siteInfo', 'copyright'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">FAVICON URL</label>
                    <input
                      type="url"
                      value={config.siteInfo.favicon || ''}
                      onChange={(e) => updateConfig(['siteInfo', 'favicon'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                      placeholder="https://example.com/favicon.ico"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">OG IMAGE URL</label>
                    <input
                      type="url"
                      value={config.siteInfo.ogImage || ''}
                      onChange={(e) => updateConfig(['siteInfo', 'ogImage'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                      placeholder="https://example.com/og-image.jpg"
                    />
                  </div>
                  
                  <div className="md:col-span-2">
                    <label className="block text-blue-400 font-mono text-sm mb-2">DESCRIPTION</label>
                    <textarea
                      value={config.siteInfo.description}
                      onChange={(e) => updateConfig(['siteInfo', 'description'], e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                    />
                  </div>
                  
                  <div className="md:col-span-2">
                    <label className="block text-blue-400 font-mono text-sm mb-2">KEYWORDS (comma separated)</label>
                    <input
                      type="text"
                      value={(config.siteInfo.keywords || []).join(', ')}
                      onChange={(e) => updateConfig(['siteInfo', 'keywords'], e.target.value.split(',').map(k => k.trim()))}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                      placeholder="DJ, House, Techno, NYC, Electronic"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'members' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-blue-400 font-mono">DJ MEMBERS</h2>
                  <button
                    onClick={() => addArrayItem(['members'], {
                      id: `member_${Date.now()}`,
                      name: 'New DJ',
                      origin: 'City, State',
                      specialty: 'Genre',
                      equipment: 'Equipment',
                      yearsActive: 1,
                      status: 'online',
                      bio: '',
                      profileImage: '',
                      socialLinks: []
                    })}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded font-mono text-sm"
                  >
                    <Plus size={16} />
                    ADD MEMBER
                  </button>
                </div>
                
                <div className="space-y-4">
                  {config.members.map((member, index) => (
                    <div key={member.id} className="bg-gray-800 border border-gray-600 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-bold text-cyan-400 font-mono">MEMBER {index + 1}</h3>
                        <div className="flex gap-2">
                          <button
                            onClick={() => duplicateItem(['members'], index)}
                            className="text-blue-400 hover:text-blue-300"
                            title="Duplicate"
                          >
                            <Copy size={16} />
                          </button>
                          <button
                            onClick={() => removeArrayItem(['members'], index)}
                            className="text-red-400 hover:text-red-300"
                            title="Delete"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">NAME</label>
                          <input
                            type="text"
                            value={member.name}
                            onChange={(e) => updateConfig(['members', index, 'name'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">ORIGIN</label>
                          <input
                            type="text"
                            value={member.origin}
                            onChange={(e) => updateConfig(['members', index, 'origin'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">SPECIALTY</label>
                          <input
                            type="text"
                            value={member.specialty}
                            onChange={(e) => updateConfig(['members', index, 'specialty'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">EQUIPMENT</label>
                          <input
                            type="text"
                            value={member.equipment}
                            onChange={(e) => updateConfig(['members', index, 'equipment'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">YEARS ACTIVE</label>
                          <input
                            type="number"
                            value={member.yearsActive}
                            onChange={(e) => updateConfig(['members', index, 'yearsActive'], parseInt(e.target.value))}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">STATUS</label>
                          <select
                            value={member.status}
                            onChange={(e) => updateConfig(['members', index, 'status'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          >
                            <option value="online">Online</option>
                            <option value="offline">Offline</option>
                            <option value="busy">Busy</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">PROFILE IMAGE URL</label>
                          <input
                            type="url"
                            value={member.profileImage || ''}
                            onChange={(e) => updateConfig(['members', index, 'profileImage'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                            placeholder="https://example.com/profile.jpg"
                          />
                        </div>
                        
                        <div className="md:col-span-2">
                          <label className="block text-blue-400 font-mono text-sm mb-2">BIO</label>
                          <textarea
                            value={member.bio || ''}
                            onChange={(e) => updateConfig(['members', index, 'bio'], e.target.value)}
                            rows={3}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                            placeholder="Member biography..."
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Continue with other comprehensive sections... */}
            {activeTab === 'story' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-blue-400 font-mono">STORY & TIMELINE</h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">STORY TITLE</label>
                    <input
                      type="text"
                      value={config.story.title}
                      onChange={(e) => updateConfig(['story', 'title'], e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-blue-400 font-mono text-sm mb-2">STORY CONTENT</label>
                    <textarea
                      value={config.story.content}
                      onChange={(e) => updateConfig(['story', 'content'], e.target.value)}
                      rows={8}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded text-white font-mono"
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-cyan-400 font-mono">TIMELINE</h3>
                    <button
                      onClick={() => addArrayItem(['story', 'timeline'], {
                        year: new Date().getFullYear().toString(),
                        event: 'New Event',
                        description: 'Event description'
                      })}
                      className="flex items-center gap-2 bg-green-600 hover:bg-green-700 px-4 py-2 rounded font-mono text-sm"
                    >
                      <Plus size={16} />
                      ADD EVENT
                    </button>
                  </div>
                  
                  {(config.story.timeline || []).map((event, index) => (
                    <div key={index} className="bg-gray-800 border border-gray-600 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-orange-400 font-mono">EVENT {index + 1}</h4>
                        <button
                          onClick={() => removeArrayItem(['story', 'timeline'], index)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-blue-400 font-mono text-sm mb-2">YEAR</label>
                          <input
                            type="text"
                            value={event.year}
                            onChange={(e) => updateConfig(['story', 'timeline', index, 'year'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div className="md:col-span-2">
                          <label className="block text-blue-400 font-mono text-sm mb-2">EVENT</label>
                          <input
                            type="text"
                            value={event.event}
                            onChange={(e) => updateConfig(['story', 'timeline', index, 'event'], e.target.value)}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                        
                        <div className="md:col-span-3">
                          <label className="block text-blue-400 font-mono text-sm mb-2">DESCRIPTION</label>
                          <textarea
                            value={event.description}
                            onChange={(e) => updateConfig(['story', 'timeline', index, 'description'], e.target.value)}
                            rows={2}
                            className="w-full px-3 py-2 bg-gray-900 border border-gray-600 rounded text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Add more comprehensive sections for all other tabs... */}
          </main>
        </div>
      )}
    </div>
  );
};