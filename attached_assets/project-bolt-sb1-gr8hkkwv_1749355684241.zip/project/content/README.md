# Content Management Guide

This guide will help you update your Need For Groove website without any programming knowledge. All content is managed through simple text files that you can edit.

## 📁 File Structure

```
content/
├── site-config.json     # Main site configuration
├── images/             # Your custom images folder
└── README.md          # This guide
```

## 🎯 Quick Start

### 1. Updating Basic Site Information

Open `site-config.json` and edit the `siteInfo` section:

```json
"siteInfo": {
  "title": "Your Site Title",
  "logo": "Your Logo Text",
  "copyright": "(C) 2024 Your Name",
  "description": "Your description here"
}
```

### 2. Updating DJ Member Information

Edit the `members` array to change DJ profiles:

```json
"members": [
  {
    "id": "member_01",
    "name": "Your Name",
    "origin": "Your City, State",
    "specialty": "Your Music Style",
    "equipment": "Your Equipment",
    "yearsActive": 5,
    "status": "online"
  }
]
```

### 3. Adding/Updating DJ Sets

Edit the `djSets` array:

```json
"djSets": [
  {
    "title": "YOUR SET NAME",
    "details": "Venue · Year",
    "duration": "01:30:00",
    "thumbnail": "https://your-image-url.com/image.jpg",
    "url": "https://link-to-your-set.com"
  }
]
```

### 4. Managing Bookings

Update the `bookings` array:

```json
"bookings": [
  {
    "date": "15 JUN 2025",
    "venue": "VENUE NAME",
    "location": "CITY, STATE",
    "type": "CLUB",
    "status": "confirmed"
  }
]
```

**Status options:** `confirmed`, `pending`, `cancelled`
**Type options:** `CLUB`, `WAREHOUSE`, `FESTIVAL`, `OUTDOOR`, `PRIVATE`

### 5. Adding Releases

Update the `releases` array:

```json
"releases": [
  {
    "title": "Your Release Name",
    "label": "Record Label",
    "year": "2024",
    "cover": "https://your-cover-image.com/cover.jpg",
    "url": "https://link-to-release.com"
  }
]
```

### 6. Updating Contact Information

Edit the `contact` section:

```json
"contact": {
  "bookings": {
    "email": "your-booking-email@domain.com",
    "phone": "+1 (555) 123-4567"
  },
  "management": {
    "email": "management@domain.com",
    "company": "Your Management Company"
  },
  "press": {
    "email": "press@domain.com",
    "note": "Press Kit Available"
  }
}
```

## 🖼️ Managing Images

### Using External Images (Recommended)
- Upload images to services like:
  - **Imgur** (free, easy)
  - **Cloudinary** (professional)
  - **Your hosting provider**
- Copy the direct image URL
- Paste it in the JSON file

### Image Size Recommendations
- **DJ Set Thumbnails:** 400x225px (16:9 ratio)
- **Release Covers:** 300x300px (square)
- **General Images:** 1200px width maximum

### Finding Free Images
- **Pexels** (https://pexels.com) - Free stock photos
- **Unsplash** (https://unsplash.com) - Free high-quality images
- **Pixabay** (https://pixabay.com) - Free images and music

## 🎵 Adding Audio/Video Links

### For DJ Sets and Releases
Replace the `"url": "#"` with your actual links:
- **SoundCloud:** `"url": "https://soundcloud.com/your-track"`
- **Mixcloud:** `"url": "https://mixcloud.com/your-mix"`
- **YouTube:** `"url": "https://youtube.com/watch?v=your-video"`
- **Spotify:** `"url": "https://open.spotify.com/track/your-track"`

## 📱 Social Media Links

Update the `socialLinks` array:

```json
"socialLinks": [
  {
    "name": "Instagram",
    "url": "https://instagram.com/your-handle"
  },
  {
    "name": "SoundCloud",
    "url": "https://soundcloud.com/your-profile"
  }
]
```

## ⚠️ Important Tips

### JSON Formatting Rules
1. **Always use double quotes** around text: `"text"`
2. **No trailing commas** after the last item in a list
3. **Check your brackets** - every `{` needs a `}`
4. **Validate your JSON** at https://jsonlint.com before saving

### Common Mistakes to Avoid
- ❌ `'single quotes'` → ✅ `"double quotes"`
- ❌ `"text",` (trailing comma) → ✅ `"text"`
- ❌ Broken image links → ✅ Test image URLs first

### Testing Your Changes
1. Save your `site-config.json` file
2. Refresh your website
3. Check that all content appears correctly
4. Test all links and images

## 🆘 Troubleshooting

### Site Not Loading?
- Check JSON syntax at https://jsonlint.com
- Look for missing commas or quotes
- Ensure all brackets are properly closed

### Images Not Showing?
- Test image URLs in a new browser tab
- Make sure URLs start with `https://`
- Check image file extensions (.jpg, .png, .gif)

### Need Help?
- Use a JSON validator: https://jsonlint.com
- Check the original working file for reference
- Make small changes and test frequently

## 🔄 Backup Your Content

**Always keep a backup** of your working `site-config.json` file before making changes!

---

*This system lets you update your entire website by editing just one file. No coding required!*